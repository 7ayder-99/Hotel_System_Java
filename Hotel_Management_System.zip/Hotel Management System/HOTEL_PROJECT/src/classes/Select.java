package classes;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import classes.InsertUpdateDeletee;
import classes.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author moooo22
 */
public class Select {
    public static ResultSet getData(String Query){
    
    Connection con;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotttel?autoReconnect=true&useSSL=false","root","root123");
        } catch (SQLException ex) {
            Logger.getLogger(Select.class.getName()).log(Level.SEVERE, null, ex);
        }
Statement st=null;
    ResultSet rs=null;
    try{
    con=connection.getCon();
    st=con.createStatement();
    rs=st.executeQuery(Query);
    return rs;
    }
    catch(Exception e){
    System.out.println("ha");
    return rs;
    
    }
    
    
    }
    
}
