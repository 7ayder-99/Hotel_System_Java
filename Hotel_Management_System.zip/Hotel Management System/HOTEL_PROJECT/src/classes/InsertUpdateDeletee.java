/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package classes;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import classes.InsertUpdateDeletee;
import classes.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.awt.Toolkit;
import java.awt.event.WindowEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author moooo22
 */
public class InsertUpdateDeletee {
    
    public static void setData(String Query,String ms){
   Connection con;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotttel?autoReconnect=true&useSSL=false","root","root123");
        } catch (SQLException ex) {
            Logger.getLogger(InsertUpdateDeletee.class.getName()).log(Level.SEVERE, null, ex);
        }
    Statement st=null;
    try{
        con=connection.getCon();
        st=con.createStatement();
        st.executeUpdate(Query);
        if(!ms.equals(""))
            JOptionPane.showMessageDialog(null, ms);
    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null,e);
    }
    finally{
         try{
    }
    catch(Exception e){
    }
    
    }
    
    
    }
}
